﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.BL;
using EMS.Exception;
using System.Data;
using System.Data.SqlClient;
public partial class AdminProjectAllocationPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            LoginValidations validationObj = new LoginValidations();
            DataTable memberAdded = new DataTable();
            memberAdded = validationObj.SessionNameBL(Session["user"].ToString());
            lblUser.Text = memberAdded.Rows[0]["EmpFName"].ToString() + " " + memberAdded.Rows[0]["EmpLName"].ToString();
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
    }
    protected void btnProjects_Click(object sender, EventArgs e)
    {
        GridView2.Visible = true;
    }
    protected void btnPending_Click(object sender, EventArgs e)
    {
        GridView1.Visible = true;
    }
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
      
    }
    protected void btnAllocateProject_Click(object sender, EventArgs e)
    {
        try
        {
            Project proj = new Project();
            proj.EmpID = Convert.ToInt32(txtEmpID.Text);
            proj.ProjectID = Convert.ToInt32(txtProjectID.Text);
            AdminValidations adminValidation = new AdminValidations();
            bool projAdded = adminValidation.AddProjectBL(proj);
            if (projAdded)
            {
                Response.Write("<script> alert('Employee alloacted to the ProjectID'); </script>");
            }

            else
            {
                Response.Write("<script>alert('Employee not allocated to the  Project');</script>");
            }
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
    }
}