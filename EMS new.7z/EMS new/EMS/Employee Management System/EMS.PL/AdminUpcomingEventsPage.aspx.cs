﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using EMS.BL;
using EMS.Entity;
using EMS.PL;
using EMS.Exception;
using System.Data.SqlClient;

public partial class AdminUpcomingEventsPage : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            AdminValidations adminValid = new AdminValidations();
            DataTable table = adminValid.BirthdayBL();
            grdUpcomingEvents.DataSource = table;
            grdUpcomingEvents.DataBind();
            LoginValidations validationObj = new LoginValidations();
            DataTable memberAdded = new DataTable();
            memberAdded = validationObj.SessionNameBL(Session["user"].ToString());
            lblUser.Text = memberAdded.Rows[0]["EmpFName"].ToString() + " " + memberAdded.Rows[0]["EmpLName"].ToString();
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }

    }

    protected void grdUpcomingEvents_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

  
}