﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.BL;
using EMS.Entity;
using EMS.Exception;
using System.Data;
using System.Data.SqlClient;

public partial class EmployeeMyProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            LoginValidations validationObj = new LoginValidations();
            DataTable memberAdded = new DataTable();
            memberAdded = validationObj.SessionNameBL(Session["user"].ToString());
            lblUser.Text = memberAdded.Rows[0]["EmpFName"].ToString() + " " + memberAdded.Rows[0]["EmpLName"].ToString();
            string userName = Session["User"].ToString();
            EmployeeValidations empValid = new EmployeeValidations();
            DataTable table = empValid.MyInfo(userName);

            if (table != null)
            {
                lblUserID.Text = table.Rows[0]["UserID"].ToString();
                lblEmployeeID.Text = table.Rows[0]["EmpID"].ToString();
                lblFirstName.Text = table.Rows[0]["EmpFName"].ToString();
                lblLastName.Text = table.Rows[0]["EmpLName"].ToString();
                lblGender.Text = table.Rows[0]["EmpGender"].ToString();
                lblDOB.Text = table.Rows[0]["EmpDOB"].ToString();
                lblDOJ.Text = table.Rows[0]["EmpDOJ"].ToString();
                lblSalary.Text = table.Rows[0]["EmpSalary"].ToString();
                lblAge.Text = table.Rows[0]["EmpAge"].ToString();
                lblDesignation.Text = table.Rows[0]["EmpDesignation"].ToString();
                lblEmailID.Text = table.Rows[0]["EmpEmailId"].ToString();
                lblContactNo.Text = table.Rows[0]["EmpContactNo"].ToString();
                lblAddress.Text = table.Rows[0]["EmpAddress"].ToString();
                lblSkill.Text = table.Rows[0]["EmpSkills"].ToString();

            }
            else
            {
                Response.Write("Record Not Found");
            }
        }

        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
    }
}