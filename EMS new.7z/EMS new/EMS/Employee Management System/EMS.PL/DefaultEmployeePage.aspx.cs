﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using EMS.BL;
using System.Data.SqlClient;
using EMS.Exception;

public partial class DefaultEmployeePage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["User"] == null || Session["User"] == String.Empty)
            {
                Response.Redirect("Login.aspx");

            }
            else
            {

                LoginValidations validationObj = new LoginValidations();
                DataTable memberAdded = new DataTable();
                memberAdded = validationObj.SessionNameBL(Session["user"].ToString());
                lblUser.Text = memberAdded.Rows[0]["EmpFName"].ToString() + " " + memberAdded.Rows[0]["EmpLName"].ToString();
            }
        }
        catch (CustomException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SqlException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }
        catch (SystemException ex)
        {
            Response.Write("<script> alert('" + ex.Message + "'); </script>");
        }

    }
}