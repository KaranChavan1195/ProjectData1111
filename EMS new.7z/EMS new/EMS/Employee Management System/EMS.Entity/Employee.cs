﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Class Name           :- Entity to store Employee Information
    /// Author               :- Shruti Jamgade
    /// Date Modified        :- 4 April 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    
    public class Employee
    {
        /// <summary>
        /// Property to store and retrieve EmpID
        /// </summary>
        public int EmpID { get; set; }

        /// <summary>
        /// Property to store and retrieve EmpFName
        /// </summary>
        public string EmpFName { get; set; }

        /// <summary>
        /// Property to store and retrieve EmpLName
        /// </summary>
        public string EmpLName { get; set; }

        /// <summary>
        /// Property to store and retrieve EmpGender
        /// </summary>
        public char EmpGender { get; set; }

        /// <summary>
        /// Property to store and retrieve EmpAge
        /// </summary>
        public int EmpAge { get; set; }

        /// <summary>
        /// Property to store and retrieve EmpDesignation
        /// </summary>
        public string EmpDesignation { get; set; }

        /// <summary>
        /// Property to store and retrieve EmpSkills
        /// </summary>
        public string EmpSkills { get; set; }

        /// <summary>
        /// Property to store and retrieve EmpSalary
        /// </summary>
        public double EmpSalary { get; set; }

        /// <summary>
        /// Property to store and retrieve EmpAddress
        /// </summary>
        public string EmpAddress { get; set; }

        /// <summary>
        /// Property to store and retrieve EmpDOB
        /// </summary>
        public DateTime EmpDOB { get; set; }

        /// <summary>
        /// Property to store and retrieve EmpDOJ
        /// </summary>
        public DateTime EmpDOJ { get; set; }

        /// <summary>
        /// Property to store and retrieve EmpContactNo
        /// </summary>
        public string EmpContactNo { get; set; }

        /// <summary>
        /// Property to store and retrieve EmpEmailId
        /// </summary>
        public string EmpEmailId { get; set; }

        /// <summary>
        /// Property to store and retrieve UserID
        /// </summary>
        public string UserID { get; set; }

    }
}
