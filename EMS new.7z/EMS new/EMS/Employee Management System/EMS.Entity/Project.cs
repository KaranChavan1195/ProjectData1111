﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Class Name           :- Entity to store Project Information
    /// Author               :- Shruti Jamgade
    /// Date Modified        :- 4 April 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    
    public class Project
    {
         /// <summary>
        /// Property to store and retrieve EmpID
        /// </summary>
        public int EmpID { get; set; }

        /// <summary>
        /// Property to store and retrieve ProjectID
        /// </summary>
        public int ProjectID { get; set; }

        /// <summary>
        /// Property to store and retrieve ProjectName
        /// </summary>
        public string ProjectName { get; set; }

        /// <summary>
        /// Property to store and retrieve Technology
        /// </summary>
        public string ProjectTechnology { get; set; }

         /// <summary>
        /// Property to store and retrieve ProjectStatus
        /// </summary>
        public string ProjectStatus { get; set; }
    }
}

