﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.DAL;
using EMS.Entity;
using EMS.Exception;

namespace EMS.BL
{
    /// <summary>
    /// Class Name           :- Class to validate login information
    /// Author               :- Vinit Suryarao
    /// Date Modified        :- 4 April 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    
    public class LoginValidations
    {
        LoginOperations operationObj = new LoginOperations();

        public DataTable ValidateLogin(string UserID, string UserPswd)
        {
            //bool validdata = true;
            //StringBuilder sb = new StringBuilder();

            //if (validdata == false)
            //    throw new CustomException(sb.ToString());
            //return validdata;

            DataTable table = new DataTable();
            table = operationObj.ValidateUser(UserID, UserPswd);
            return table;
        }


        public DataTable ValidateUserBL(string UserID, string UserPswd)
        {
            try
            {
                DataTable memberTable = operationObj.ValidateUser(UserID, UserPswd);
            return memberTable;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public DataTable PasswordCheckBL(string UserID)
        {
            try
            {
                DataTable memberTable = operationObj.PasswordCheck(UserID);
                return memberTable;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public DataTable SessionNameBL(string UserID)
        {
            try
            {
                DataTable memberTable = operationObj.SessionName(UserID);
                return memberTable;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }

        public bool PasswordSetBL(string UserID, string UserPswd)
        {
            try
            {
                bool employeeAdded = false;
                //if (ValidateLogin(UserID, UserPswd))
                    employeeAdded = operationObj.PasswordSet(UserID, UserPswd);
                return employeeAdded;

            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
        }
    }
}
