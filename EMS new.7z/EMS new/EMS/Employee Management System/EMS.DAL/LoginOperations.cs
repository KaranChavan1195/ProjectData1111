﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;
using EMS.Exception;

namespace EMS.DAL
{
    /// <summary>
    /// Class Name           :- Class contains all Login Operations
    /// Author               :- Vinit Suryarao
    /// Date Modified        :- 4 April 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    
    public class LoginOperations
    {
        SqlConnection connection;
        SqlDataReader reader;

        public LoginOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeManagementSystem"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }

        public DataTable PasswordCheck(string UserID)
        {
            try
            {

                SqlCommand cmdGetPswd = new SqlCommand("[MySchemaEMS].usp_PasswordCheck", connection);
                cmdGetPswd.CommandType = CommandType.StoredProcedure;
                cmdGetPswd.Parameters.AddWithValue("@UserID", UserID);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdGetPswd.ExecuteReader();
                DataTable loginTable = new DataTable();
                loginTable.Load(reader);
                return loginTable;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public bool PasswordSet(string UserID, string UserPswd)
        {
            try
            {
                bool setpswd = false;
                SqlCommand cmdSetPswd = new SqlCommand("[MySchemaEMS].usp_PasswordSet", connection);
                cmdSetPswd.CommandType = CommandType.StoredProcedure;
                cmdSetPswd.Parameters.AddWithValue("@UserID", UserID);
                cmdSetPswd.Parameters.AddWithValue("@UserPswd", UserPswd);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                int result = cmdSetPswd.ExecuteNonQuery();
                if (result > 0)
                    setpswd = true;
                return setpswd;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public DataTable ValidateUser(string UserID, string UserPswd)
        {
            try
            {

                SqlCommand cmdValid = new SqlCommand("[MySchemaEMS].usp_ValidateLoginDetails", connection);
                cmdValid.CommandType = CommandType.StoredProcedure;
                cmdValid.Parameters.AddWithValue("@UserID", UserID);
                cmdValid.Parameters.AddWithValue("@UserPswd", UserPswd);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdValid.ExecuteReader();
                DataTable loginTable = new DataTable();
                loginTable.Load(reader);
                return loginTable;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public DataTable SessionName(string UserID)
        {
            try
            {

                SqlCommand cmdGetPswd = new SqlCommand("[MySchemaEMS].SessionName", connection);
                cmdGetPswd.CommandType = CommandType.StoredProcedure;
                cmdGetPswd.Parameters.AddWithValue("@UserID", UserID);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdGetPswd.ExecuteReader();
                DataTable loginTable = new DataTable();
                loginTable.Load(reader);
                return loginTable;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
