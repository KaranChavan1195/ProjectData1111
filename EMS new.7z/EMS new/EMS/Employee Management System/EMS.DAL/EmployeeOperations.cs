﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;
using EMS.Exception;

namespace EMS.DAL
{
    /// <summary>
    /// Class Name           :- Class contains all Employee Operations
    /// Author               :- Vinit Suryarao
    /// Date Modified        :- 4 April 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    
    public class EmployeeOperations
    {
        SqlConnection connection;
        SqlDataReader reader;

        public EmployeeOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeManagementSystem"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
        public bool EmpUpdateRecord(Employee employeeObj)
        {
            try
            {
                bool employeeAdded = false;
                SqlCommand cmdAdd = new SqlCommand("[MySchemaEMS].usp_UpdateEmployeeInfo", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@EmpID", employeeObj.EmpID);
                cmdAdd.Parameters.AddWithValue("@EmpFName", employeeObj.EmpFName);
                cmdAdd.Parameters.AddWithValue("@EmpLName", employeeObj.EmpLName);
                cmdAdd.Parameters.AddWithValue("@EmpAge", employeeObj.EmpAge);
                cmdAdd.Parameters.AddWithValue("@EmpSkills", employeeObj.EmpSkills);
                cmdAdd.Parameters.AddWithValue("@EmpAddress", employeeObj.EmpAddress);
                cmdAdd.Parameters.AddWithValue("@EmpDOB", employeeObj.EmpDOB);
                cmdAdd.Parameters.AddWithValue("@EmpContactNo", employeeObj.EmpContactNo);
                cmdAdd.Parameters.AddWithValue("@EmpEmailId", employeeObj.EmpEmailId);
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    employeeAdded = true;
                return employeeAdded;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public DataTable MyInfo(string UserID)
        {
            try
            {
                SqlCommand cmdSearch = new SqlCommand("[MySchemaEMS].usp_EmployeeInfo", connection);
                cmdSearch.CommandType = CommandType.StoredProcedure;
                cmdSearch.Parameters.AddWithValue("@UserID", UserID);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdSearch.ExecuteReader();
                DataTable employeeTable = new DataTable();
                employeeTable.Load(reader);
                return employeeTable;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

        }

        public DataTable Birthday()
        {
            try
            {
                SqlCommand cmdBday = new SqlCommand("[MySchemaEMS].usp_EmployeeBirthday", connection);
                cmdBday.CommandType = CommandType.StoredProcedure;
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdBday.ExecuteReader();
                DataTable bdayTable = new DataTable();
                bdayTable.Load(reader);
                return bdayTable;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

        }
    }
}
