﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;
using EMS.Exception;

namespace EMS.DAL
{
    /// <summary>
    /// Class Name           :- Class contains all Admin Operations
    /// Author               :- Vinit Suryarao
    /// Date Modified        :- 4 April 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    /// 
    public class AdminOperations
    {
        SqlConnection connection;
        SqlDataReader reader;

        public AdminOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["EmployeeManagementSystem"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }

        public bool AddRecord(Employee employeeObj)
        {
            try
            {
                bool employeeAdded = false;
                SqlCommand cmdAdd = new SqlCommand("[MySchemaEMS].usp_AddEmployeeRecord", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@EmpFName", employeeObj.EmpFName);
                cmdAdd.Parameters.AddWithValue("@EmpLName", employeeObj.EmpLName);
                cmdAdd.Parameters.AddWithValue("@EmpGender", employeeObj.EmpGender);
                cmdAdd.Parameters.AddWithValue("@EmpAge", employeeObj.EmpAge);
                cmdAdd.Parameters.AddWithValue("@EmpDesignation", employeeObj.EmpDesignation);
                cmdAdd.Parameters.AddWithValue("@EmpSkills", employeeObj.EmpSkills);
                cmdAdd.Parameters.AddWithValue("@EmpSalary", employeeObj.EmpSalary);
                cmdAdd.Parameters.AddWithValue("@EmpAddress", employeeObj.EmpAddress);
                cmdAdd.Parameters.AddWithValue("@EmpDOB", employeeObj.EmpDOB);
                cmdAdd.Parameters.AddWithValue("@EmpDOj", employeeObj.EmpDOJ);
                cmdAdd.Parameters.AddWithValue("@EmpContactNo", employeeObj.EmpContactNo);
                cmdAdd.Parameters.AddWithValue("@EmpEmailId", employeeObj.EmpEmailId);
                cmdAdd.Parameters.AddWithValue("@UserID", employeeObj.UserID);
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    employeeAdded = true;
                return employeeAdded;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public bool AdminUpdateRecord(Employee employeeObj)
        {
            try
            {
                bool employeeUpdt = false;
                SqlCommand cmdAdd = new SqlCommand("[MySchemaEMS].usp_UpdateEmployeeRecord", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@EmpID", employeeObj.EmpID);
                cmdAdd.Parameters.AddWithValue("@EmpFName", employeeObj.EmpFName);
                cmdAdd.Parameters.AddWithValue("@EmpLName", employeeObj.EmpLName);
                cmdAdd.Parameters.AddWithValue("@EmpGender", employeeObj.EmpGender);
                cmdAdd.Parameters.AddWithValue("@EmpAge", employeeObj.EmpAge);
                cmdAdd.Parameters.AddWithValue("@EmpDesignation", employeeObj.EmpDesignation);
                cmdAdd.Parameters.AddWithValue("@EmpSkills", employeeObj.EmpSkills);
                cmdAdd.Parameters.AddWithValue("@EmpSalary", employeeObj.EmpSalary);
                cmdAdd.Parameters.AddWithValue("@EmpAddress", employeeObj.EmpAddress);
                cmdAdd.Parameters.AddWithValue("@EmpDOB", employeeObj.EmpDOB);
                cmdAdd.Parameters.AddWithValue("@EmpDOJ", employeeObj.EmpDOJ);
                cmdAdd.Parameters.AddWithValue("@EmpContactNo", employeeObj.EmpContactNo);
                cmdAdd.Parameters.AddWithValue("@EmpEmailId", employeeObj.EmpEmailId);
                cmdAdd.Parameters.AddWithValue("@UserID", employeeObj.UserID);
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    employeeUpdt = true;
                return employeeUpdt;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

      

        public bool DeleteRecord(int EmpID)
        {
            try
            {
                bool empDelete = false;
                SqlCommand cmdDelete = new SqlCommand("[MySchemaEMS].usp_DeleteEmployeeRecord", connection);
                cmdDelete.CommandType = CommandType.StoredProcedure;
                cmdDelete.Parameters.AddWithValue("@EmpID", EmpID);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                int result = cmdDelete.ExecuteNonQuery();
                if (result > 0) 
                    empDelete = true;
                    return empDelete;
                
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

        }

        public DataTable SearchRecord(string param)
        {
            try
            {
                SqlCommand cmdSearch = new SqlCommand("[MySchemaEMS].usp_SearchEmployee", connection);
                cmdSearch.CommandType = CommandType.StoredProcedure;
                cmdSearch.Parameters.AddWithValue("@EmpSearch", param);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdSearch.ExecuteReader();
                DataTable employeeTable = new DataTable();
                employeeTable.Load(reader);
                return employeeTable;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

        }

        public bool AddProject(Project projectObj)
        {
            try
            {
                bool projAdd = false;
                SqlCommand cmdAdd = new SqlCommand("[MySchemaEMS].usp_AllocateEmployee", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@EmpID", projectObj.EmpID);
                cmdAdd.Parameters.AddWithValue("@ProjectID", projectObj.ProjectID);
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    projAdd = true;
                return projAdd;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public DataTable Birthday()
        {
            try
            {
                SqlCommand cmdBday = new SqlCommand("[MySchemaEMS].usp_EmployeeBirthday", connection);
                cmdBday.CommandType = CommandType.StoredProcedure;
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdBday.ExecuteReader();
                DataTable employeeTable = new DataTable();
                employeeTable.Load(reader);
                return employeeTable;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

        }

        public DataTable MyInfo(string UserID)
        {
            try
            {
                SqlCommand cmdSearch = new SqlCommand("[MySchemaEMS].usp_EmployeeInfo", connection);
                cmdSearch.CommandType = CommandType.StoredProcedure;
                cmdSearch.Parameters.AddWithValue("@UserID", UserID);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdSearch.ExecuteReader();
                DataTable employeeTable = new DataTable();
                employeeTable.Load(reader);
                return employeeTable;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

        }


        public DataTable SearchRecordByID(int empId)
        {
            try
            {
                SqlCommand cmdSearch = new SqlCommand("[MySchemaEMS].usp_SearchEmployeeByID", connection);
                cmdSearch.CommandType = CommandType.StoredProcedure;
                cmdSearch.Parameters.AddWithValue("@EmpID", empId);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdSearch.ExecuteReader();
                DataTable employeeTable = new DataTable();
                employeeTable.Load(reader);
                return employeeTable;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

       
    }
}
